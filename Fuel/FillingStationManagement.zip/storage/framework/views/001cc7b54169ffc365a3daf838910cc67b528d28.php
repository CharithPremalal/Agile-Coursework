
<!DOCTYPE html>
<html lang="en">
<!-- START: Head-->



<head>
    <meta charset="UTF-8">
    <title>Pick Admin</title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('dist/images/favicon.ico')); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <!-- START: Template CSS-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/jquery-ui/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/jquery-ui/jquery-ui.theme.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/simple-line-icons/css/simple-line-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/flags-icon/css/flag-icon.min.css')); ?>">

    <!-- END Template CSS-->

    <!-- START: Page CSS-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/social-button/bootstrap-social.css')); ?>">
    <!-- END: Page CSS-->

    <!-- START: Custom CSS-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/css/main.css')); ?>">
    <!-- END: Custom CSS-->
</head>
<!-- END Head-->

<!-- START: Body-->

<body id="main-container" class="default" style="background-image: url('dist/images/infa_Deh_fill_03.jpg');  background-position: center; background-repeat: no-repeat; background-size: cover; ">
    <!-- START: Main Content-->
    <div class="container ">
        <div class="row vh-100 justify-content-between align-items-center ">
            <div class="col-12 ">
                <form method="POST" action="<?php echo e(route('login')); ?>" class="row row-eq-height lockscreen mt-5 mb-5 ">
                <?php echo csrf_field(); ?>
                    <div class="lock-image col-12 col-sm-5 "></div>
                    <div class="login-form col-12 col-sm-7 ">
                        <div class="form-group mb-3 ">
                            <label for="email "><?php echo e(__('E-Mail Address')); ?></label>
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="E-mail" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-3 ">
                            <label for="password">Password</label>
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-3 ">
                            <div class="custom-control custom-checkbox ">
                                <input type="checkbox" class="custom-control-input "  name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label class="custom-control-label " for="remember"><?php echo e(__('Remember Me')); ?></label>
                            </div>
                        </div>

                        <div class="form-group mb-0 ">
                            <button class="btn btn-primary " type="submit"><?php echo e(__('Login')); ?></button>
                        </div>
                        
                        <div class="mt-2 ">Forgot Password? 
                        <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('here')); ?></a>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                </form>
            </div>

        </div>
    </div>
    <!-- END: Content-->

    <!-- START: Template JS-->
    <script src="<?php echo e(URL::asset('dist/vendors/jquery/jquery-3.3.1.min.js ')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-ui/jquery-ui.min.js ')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/moment/moment.js ')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/bootstrap/js/bootstrap.bundle.min.js ')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/slimscroll/jquery.slimscroll.min.js ')); ?>"></script>

    <!-- END: Template JS-->
</body>
<!-- END: Body-->



</html>
<?php /**PATH C:\Users\Minu Helaka\Desktop\FillingStationManagement\resources\views/auth/login.blade.php ENDPATH**/ ?>