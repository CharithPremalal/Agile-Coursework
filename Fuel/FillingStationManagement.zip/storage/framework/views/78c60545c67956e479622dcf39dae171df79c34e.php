<!DOCTYPE html>
<html lang="en">
<!-- START: Head-->



<head>
    <meta charset="UTF-8">
    <title>Fuel App</title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('dist/images/logo.png')); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <!-- START: Template CSS-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/jquery-ui/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/jquery-ui/jquery-ui.theme.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/simple-line-icons/css/simple-line-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/flags-icon/css/flag-icon.min.css')); ?>">
    <!-- END Template CSS-->
    <!-- START: Page CSS-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/datatable/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/datatable/buttons/css/buttons.bootstrap4.min.css')); ?>">
    <!-- END: Page CSS-->

    <!-- START: Page CSS-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/vendors/quill/quill.snow.css')); ?>">
    <!-- END: Page CSS-->

    <link rel="stylesheet" href="<?php echo e(URL::asset('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css')); ?>">

    <!-- START: Custom CSS-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('dist/css/main.css')); ?>">
    <!-- END: Custom CSS-->
</head>
<!-- END Head-->

<!-- START: Body-->

<body id="main-container" class="default">
    <!-- START: Pre Loader-->
    <div class="se-pre-con">
        <div class="loader"></div>
    </div>
    <!-- END: Pre Loader-->

    <!-- START: Header-->
    <div id="header-fix" class="header fixed-top">
        <div class="site-width">
            <nav class="navbar navbar-expand-lg  p-0">
                <div class="navbar-header  h-100 h4 mb-0 align-self-center logo-bar text-left">
                    <a href="/dashboard" class="horizontal-logo text-left">
                        <span class="h4 font-weight-bold align-self-center mb-0 ml-auto">Fuel</span>
                    </a>
                </div>
                <div class="navbar-header h4 mb-0 text-center h-100 collapse-menu-bar">
                    <a href="#" class="sidebarCollapse" id="collapse"><i class="icon-menu"></i></a>
                </div>

                <form class="float-left d-none d-lg-block search-form">
                    <div class="form-group mb-0 position-relative">
                        <input type="text" class="form-control border-0 rounded bg-search pl-5" placeholder="Search anything...">
                        <div class="btn-search position-absolute top-0">
                            <a href="#"><i class="h6 icon-magnifier"></i></a>
                        </div>
                        <a href="#" class="position-absolute close-button mobilesearch d-lg-none" data-toggle="dropdown" aria-expanded="false"><i class="icon-close h5"></i>                               
                            </a>

                    </div>
                </form>
                <div class="navbar-right ml-auto h-100">
                    <ul class="ml-auto p-0 m-0 list-unstyled d-flex top-icon h-100">
                        <li class="d-inline-block align-self-center  d-block d-lg-none">
                            <a href="#" class="nav-link mobilesearch" data-toggle="dropdown" aria-expanded="false"><i class="icon-magnifier h4"></i>                               
                                </a>
                        </li>
                        <li class="dropdown align-self-center d-inline-block">
                            <a href="#" class="nav-link" data-toggle="dropdown" aria-expanded="false"><i class="icon-bell h4"></i>
                                    <span class="badge badge-default"> <span class="">
                                        </span><span class="ring-point">
                                        </span> </span>
                                </a>
                        </li>
                        <li class="dropdown user-profile align-self-center d-inline-block">
                            <a href="#" class="nav-link py-0" data-toggle="dropdown" aria-expanded="false">
                                <div class="media">
                                    <img src="dist/images/avatr.png" class="d-flex img-fluid rounded-circle" width="29">
                                </div>
                            </a>

                            <div class="dropdown-menu border dropdown-menu-right p-0">
                                <a href="#" class="dropdown-item px-2 align-self-center d-flex">
                                    <span class="icon-pencil mr-2 h6 mb-0"></span> Edit Profile</a>
                                <a href="<?php echo e(url('profile')); ?>" class="dropdown-item px-2 align-self-center d-flex">
                                    <span class="icon-user mr-2 h6 mb-0"></span> View Profile</a>
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item px-2 align-self-center d-flex">
                                    <span class="icon-support mr-2 h6  mb-0"></span> Help Center</a>
                                <a href="#" class="dropdown-item px-2 align-self-center d-flex">
                                    <span class="icon-settings mr-2 h6 mb-0"></span> Account Settings</a>
                                <div class="dropdown-divider"></div>
                                <a href="page-login.html" class="dropdown-item px-2 text-danger align-self-center d-flex">
                                    <span class="icon-logout mr-2 h6  mb-0"></span> Sign Out</a>
                            </div>

                        </li>

                    </ul>
                </div>
            </nav>
        </div>
    </div>
    <!-- END: Header-->

    <!-- START: Main Menu-->
    <div class="sidebar">
        <div class="site-width">

            <!-- START: Menu-->
            <ul id="side-menu" class="sidebar-menu">
                <li class="dropdown active"><a href="#"><i class="icon-home mr-1"></i> Dashboard</a>
                    <ul>
                        <li class="active"><a href="/dashboard"><i class="icon-grid"></i> Analytic</a></li>
                        <li><a href="<?php echo e(url('employee-list')); ?>"><i class="icon-people"></i> Employee List</a></li>
                    </ul>
                </li>
                <li class="dropdown"><a href="#"><i class="icon-layers mr-1"></i>Manage</a>
                    <ul>
                        <li><a href="<?php echo e(url('to-do-list')); ?>"><i class="icon-support"></i> Todo</a></li>
                        <li><a href="<?php echo e(url('task-board')); ?>"><i class="icon-event"></i> Task Board</a></li>
                        <li><a href="<?php echo e(url('notes')); ?>"><i class="icon-tag"></i> Notes</a></li>
                    </ul>
                </li>
                <li class="dropdown"><a href="#"><i class="icon-people mr-1"></i> Profile</a>
                    <ul>
                        <li><a href="<?php echo e(url('profile')); ?>"><i class="icon-user"></i>View Profile</a></li>
                        <li><a href="#"><i class="icon-pencil"></i> Edit Profile</a></li>
                        <li><a href="#"><i class="icon-settings"></i> Account Settings</a></li>
                        <li><a href="#"><i class="icon-lock"></i> Lockscreen</a></li>
                    </ul>
                </li>
            </ul>
            <!-- END: Menu-->
            <ol class="breadcrumb bg-transparent align-self-center m-0 p-0 ml-auto">
                <li class="breadcrumb-item"><a href="#">Application</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- END: Main Menu-->

    <!-- START: Main Content-->
    <main>
        <div class="container-fluid site-width">
            <!-- START: Breadcrumbs-->
            <div class="row">
                <div class="col-12  align-self-center">
                    <div class="sub-header mt-3 py-3 align-self-center d-sm-flex w-100 rounded">
                        <div class="w-sm-100 mr-auto">
                            <h4 class="mb-0">Dashboard</h4>
                            <p>Welcome to admin panel</p>
                        </div>

                        <ol class="breadcrumb bg-transparent align-self-center m-0 p-0">
                            <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
            <!-- END: Breadcrumbs-->

            <!-- START: Card Data-->
            <div class="row">
                <div class="col-12 col-sm-6 col-xl-4 mt-3">
                    <div class="card">
                        <div class="card-body p-0">
                            <div class='p-4 align-self-center'>
                                <h2><?php echo e($done); ?></h2>
                                <h6 class="card-liner-subtitle">Done</h6>
                            </div>
                            <div class="barfiller" data-color="#1e3d73">
                                <div class="tipWrap">
                                    <span class="tip rounded primary">
                                            <span class="tip-arrow"></span>
                                    </span>
                                </div>
                                <span class="fill" data-percentage="<?php echo e($doneRound); ?>"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-xl-4 mt-3">
                    <div class="card">
                        <div class="card-body p-0">
                            <div class='p-4 align-self-center'>
                                <h2><?php echo e($pending); ?></h2>
                                <h6 class="card-liner-subtitle">Pending</h6>
                            </div>
                            <div class="barfiller" data-color="#17a2b8">
                                <div class="tipWrap">
                                    <span class="tip rounded info">
                                            <span class="tip-arrow"></span>
                                    </span>
                                </div>
                                <span class="fill" data-percentage="<?php echo e($donePending); ?>"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-xl-4 mt-3">
                    <div class="card">
                        <div class="card-body p-0">
                            <div class='p-4 align-self-center'>
                                <h2><?php echo e($total); ?></h2>
                                <h6 class="card-liner-subtitle">Total</h6>
                            </div>
                            <div class="barfiller" data-color="#1ee0ac">
                                <div class="tipWrap">
                                    <span class="tip rounded success">
                                            <span class="tip-arrow"></span>
                                    </span>
                                </div>
                                <span class="fill" data-percentage="<?php echo e($doneRound); ?>"></span>
                            </div>
                        </div>
                    </div>
                </div>





            </div>
        </div>
        <!-- END: Card DATA-->

        <!-- START: Card Data-->
        <div class="row">
                <div class="col-12 mt-3">
                    <div class="card">
                        <div class="card-header  justify-content-between align-items-center">
                        <h4 class="card-title">All Check-list</h4>
                            <!-- <a href="<?php echo e(url('to-do-list-add')); ?>" class="bg-primary py-2 px-2 rounded m-auto text-white ">
                                <i class="icon-plus align-middle text-white"></i> <span>Add New</span>
                            </a> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="display table dataTable table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>Check list items</th>
                                            <th>date</th>
                                            <th>Employee Name</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($task->id); ?></td>
                                            <td><?php echo e($task->task); ?></td>
                                            <td><?php echo e($task->date); ?></td>
                                            <td><?php echo e($task->user ? $task->user->name: ''); ?></td>
                                            <!-- <td> -->
                                            <!-- <?php if($task->isCompleted): ?>
                                                <a type="button" class="btn btn-primary" href="#"><i class="fa fa-check-square-o" aria-hidden="true"></i></a>
                                            <?php else: ?> 
                                                <a type="button" class="btn btn-warning" href="#"><i class="fa fa-list" aria-hidden="true"></i></a>
                                            <?php endif; ?> -->
                                                <!-- <a type="button" class="btn btn-secondary" href="<?php echo e(route('to-do-list.edit' , $task->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> -->
                                                <!-- <a type="button" class="btn btn-danger" href="#"><i class="fa fa-trash" aria-hidden="true"></i></a> -->
                              
                                                <td>
                                            
                                            <?php if(!$task->isCompleted): ?>
                                            <a type="button" class="btn btn-warning">Pending</a>
                                            <?php else: ?>
                                            <a type="button" class="btn btn-primary" style="color: #fff">Done</a>                  
                                            <?php endif; ?>
                                            
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                    <tfoot>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- END: Card DATA-->
        </div>
    </main>
    <!-- END: Content-->
    <!-- START: Footer-->
    <!-- <footer class="site-footer">

    </footer> -->
    <!-- END: Footer-->


    <!-- START: Back to top-->
    <a href="#" class="scrollup text-center">
        <i class="icon-arrow-up"></i>
    </a>
    <!-- END: Back to top-->





    <!-- START: Template JS-->
    <script src="<?php echo e(URL::asset('dist/vendors/jquery/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
    <!-- END: Template JS-->

    <!-- START: APP JS-->
    <script src="<?php echo e(URL::asset('dist/js/app.js')); ?>"></script>
    <!-- END: APP JS-->

    <!-- START: Page Vendor JS-->
    <script src="<?php echo e(URL::asset('dist/vendors/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/morris/morris.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/chartjs/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/starrr/starrr.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.canvaswrapper.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.colorhelpers.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.flot.saturated.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.flot.browser.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.flot.drawSeries.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.flot.uiConstants.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.flot.legend.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-flot/jquery.flot.pie.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/chartjs/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-jvectormap/jquery-jvectormap-2.0.3.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-jvectormap/jquery-jvectormap-world-mill.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-jvectormap/jquery-jvectormap-de-merc.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/jquery-jvectormap/jquery-jvectormap-us-aea.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/lineprogressbar/jquery.lineProgressbar.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/lineprogressbar/jquery.barfiller.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- START: Page Vendor JS-->
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/buttons/js/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('dist/vendors/datatable/buttons/js/buttons.print.min.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- START: Page Script JS-->
    <script src="<?php echo e(URL::asset('dist/js/datatable.script.js')); ?>"></script>

    <!-- START: Page JS-->
    <script src="<?php echo e(URL::asset('dist/js/home.script.js')); ?>"></script>
    <!-- END: Page JS-->
</body>
<!-- END: Body-->



</html><?php /**PATH C:\Users\Minu Helaka\Desktop\FillingStationManagement\resources\views/Admin/dashboard.blade.php ENDPATH**/ ?>